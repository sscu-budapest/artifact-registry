import hashlib
import os
import zipfile
from itertools import islice
from pathlib import Path

from colassigner import ColAssigner
from parquetranger import TableRepo


class DoiHasher(ColAssigner):
    def __init__(self, col="doi"):
        self.col = col

    def doi_hash(self, df):
        return df[self.col].apply(lambda s: hashlib.md5(s.encode()).hexdigest())

    def doi_prefix(self, df):
        return df[DoiHasher.doi_hash].str[:2]


RAW_ROOT = Path(os.environ["RAW_DATA_SC_PATH"])

out_d = RAW_ROOT / "parsed-p"

oc_doid_meta_trepo = TableRepo(out_d / "oc-doid", group_cols=[DoiHasher.doi_prefix])
oc_nondio_trepo = TableRepo(out_d / "oc-nondoid", max_records=2_000_000)
datacite_cite_trepo, crossref_cite_trepo = (
    TableRepo(out_d / f"{name}-cites", group_cols=[DoiHasher.doi_prefix])
    for name in ["datacite", "crossref"]
)
coreference_trepo = TableRepo(out_d / "coreference")


def batched(iterable, n):
    it = iter(iterable)
    while batch := list(islice(it, n)):
        yield batch


def iteropen(zpath):
    with zipfile.ZipFile(zpath) as zfp:
        for inz in zfp.filelist:
            yield zfp.open(inz.filename)


datacite_cite_path = RAW_ROOT / "2022-12-04T163936_0-11_1-2.zip"
meta_path = RAW_ROOT / "csv.zip"
crossref_path = RAW_ROOT / "6741422"
crossref_dump = RAW_ROOT / "April 2022 Public Data File from Crossref"
