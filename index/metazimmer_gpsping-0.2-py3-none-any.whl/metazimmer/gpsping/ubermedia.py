import datetime as dt

import datazimmer as dz
import pandas as pd
from colassigner import Col

NON_COVID_MONTH = "2019-11"
COVID_MONTH = "2020-11"


class Coordinates(dz.CompositeTypeBase):
    lon = float
    lat = float


class GpsPing(dz.AbstractEntity):

    device_id = str
    datetime = dt.datetime
    loc = Coordinates


class ExtendedPing(GpsPing):
    def device_group(self, df) -> Col[str]:
        return df[GpsPing.device_id].str[:2]

    def year_month(self, df) -> Col[str]:
        return df[GpsPing.datetime].dt.isoformat().str[:7]


ping_table = dz.ScruTable(
    ExtendedPing,
    partitioning_cols=[ExtendedPing.year_month, ExtendedPing.device_group],
)

csv_cols = {1: GpsPing.device_id, 2: GpsPing.loc.lat, 3: GpsPing.loc.lon}


@dz.register_data_loader
def update_data(chunksize_mil):

    # data_path = os.environ["RAW_UM_GPS_PING_LOC"]
    data_path = "/home/borza/tmp/mobil-samp.tsv"
    chsz = chunksize_mil * 10**6
    for _df in pd.read_csv(data_path, sep="\t", header=None, chunksize=chsz):
        dump_raw(_df)


@dz.register_env_creator
def create_environments(is_covid: bool = False, ind_of_weekday: int = None):
    """create environments that are described in the config of the repo"""

    month = COVID_MONTH if is_covid else NON_COVID_MONTH
    for gid, paths in ping_table.get_partition_paths(ExtendedPing.year_month):
        if gid == month:
            df = pd.concat(map(ping_table.trepo.read_df_from_path, paths))
    weeks = df.loc[:, GpsPing.datetime].dt.isocalendar().week
    week_filter = weeks == (weeks.min() + 1)
    day_filter = df.loc[:, GpsPing.datetime].dt.dayofweek == ind_of_weekday
    full_filter = week_filter if ind_of_weekday is None else (week_filter & day_filter)
    ping_table.replace_all(df.loc[full_filter, :])


def dump_raw(raw_in):
    ping_table.extend(
        pd.read_csv(raw_in, sep="\t", header=None)
        .rename(columns=csv_cols)
        .assign(
            **{GpsPing.datetime: lambda df: pd.to_datetime(df.iloc[:, 4] * 10**9)}
        )
        .pipe(ExtendedPing())
    )
